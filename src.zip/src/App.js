// import './App.css';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import SignUp from './COMPONENT/SignUp.js'
// import SignIn from './COMPONENT/SignIn.js';
// import Footer from './COMPONENT/Footer.js';
// import Home from './COMPONENT/Home.js';
// import Professional from './COMPONENT/Professional.js'
// import Portfolio from './COMPONENT/Portfolio.js';
// import ByRoomType from './COMPONENT/ByRoomType.js';
// import Product from './COMPONENT/Product.js';
// import Header from './COMPONENT/Header.js';
// import Design from './COMPONENT/Design.js';
// import Particular from './COMPONENT/Perticuler.js';
// import Search from './COMPONENT/Search.js';

// function App() {
//   return (
//     <Router>

//     <Routes>

//        <Route path="/" element={<SignIn />} ></Route>
//         <Route path="/signUp" element={<SignUp/>}></Route>
//         <Route path = "/footer" element = {<Footer/>}></Route>
//          <Route path = "/home" element = {<Home/>}></Route> 
//         <Route path = "/professionals" element = {<Professional/>}></Route>
//         <Route path= "/product" element = {<Product/>}></Route>
//         <Route path = "/header" element = {<Header/>}></Route>
      

//       <Route path="/home" element={<Home/>} />
//       <Route path="/portfolio/:professional_id" element={<Portfolio />} />


//   <Route path="/home/professional_id/:id" element={<Portfolio />} />
// {/* viewMore button click */}
// <Route path="/portfolio/:professional_id" element={<Portfolio />} />

//   <Route path="/home/professional_id/:id/roomType_id/:roomType_id" element={<ByRoomType/>} />

// {/* ================================================================================= */}
// <Route path="/design/:design_id" element={<Design/>} />
// <Route path='/particular/:design_id' element={<Particular/>}/>
// <Route path='/search/:roomType'element={<Search/>}/>
//       </Routes>
//       </Router>
//   );
// }
// export default App;
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SignUp from './COMPONENT/SignUp.js'
import SignIn from './COMPONENT/SignIn.js';
import Footer from './COMPONENT/Footer.js';
import Home from './COMPONENT/Home.js';
import Professional from './COMPONENT/Professional.js'
import Portfolio from './COMPONENT/Portfolio.js';
import ByRoomType from './COMPONENT/ByRoomType.js';
import Product from './COMPONENT/Product.js';
import Header from './COMPONENT/Header.js';
import Design from './COMPONENT/Design.js';
import Particular from './COMPONENT/Perticuler.js';
import Search from './COMPONENT/Search.js';

function App() {
  return (
    <Router>

    <Routes>

       <Route path="/" element={<SignIn />} ></Route>
        <Route path="/signUp" element={<SignUp/>}></Route>
      <Route path="/home" element={<Home/>} />
        <Route path = "/footer" element = {<Footer/>}></Route>
         <Route path = "/home" element = {<Home/>}></Route> 
        <Route path = "/professionals" element = {<Professional/>}></Route>
        <Route path= "/product" element = {<Product/>}></Route>
        <Route path = "/header" element = {<Header/>}></Route>
      

      <Route path="/portfolio/:professional_id" element={<Portfolio />} />


  <Route path="/home/professional_id/:id" element={<Portfolio />} />
{/* viewMore button click */}
<Route path="/portfolio/:professional_id" element={<Portfolio />} />

  <Route path="/home/professional_id/:id/roomType_id/:roomType_id" element={<ByRoomType/>} />

{/* ================================================================================= */}
<Route path="/design/:design_id" element={<Design/>} />
<Route path='/particular/:design_id' element={<Particular/>}/>
<Route path='/search/:roomType'element={<Search/>}/>




      </Routes>
      </Router>
  );
}
export default App;

