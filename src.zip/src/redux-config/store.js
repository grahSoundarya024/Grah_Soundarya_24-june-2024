import { configureStore } from "@reduxjs/toolkit";
import Professionalslice from "./Professionalslice";
import ByRoomTypeslice from "./ByRoomTypeslice";
import FavDesignslice from "./FavDesignslice";


const store = configureStore({
    reducer:{
        Professionals:Professionalslice,
        AllDesigns:ByRoomTypeslice,
        AllFavDesigns:FavDesignslice

    }
});
export default store;